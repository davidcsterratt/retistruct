Parabola demo
=============

This is generated using morph.dataset.to.parabola()
